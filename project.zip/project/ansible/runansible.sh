cd /root/automation/terraform/assignment/ansible  # Change the path to the location of the ansible playbook
echo "------------------------------------"
echo "Running ansible playbook"
echo "------------------------------------"

ansible-playbook --verbose n01622334-playbook.yaml

echo "------------------------------------"
echo "Completed ansible playbook"
echo "------------------------------------"
